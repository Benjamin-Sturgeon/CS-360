package com.example.cs_360WeightTracker;
//Benjamin Sturgeon CS-360
//necessary imports
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.cs_360WeightTracker.ChangeActivites.AddWeightDialogFragment;
import com.example.cs_360WeightTracker.ChangeActivites.EditWeightDialogFragment;
import com.example.cs_360WeightTracker.databases.creator.WeightTrackerDatabaseCreator;
import com.example.cs_360WeightTracker.databases.commands.userWeights;

import java.util.List;
import java.util.Locale;

//Here I create a separate class for weight tracking and creation with the weight database with implemented listeners
public class WeightTracker extends AppCompatActivity
        implements EditWeightDialogFragment.OnEditWeightListener,
                    AddWeightDialogFragment.OnAddWeightListener {

    //I create the necessary fields for processing
    private String dataUsername = null;
    private userWeights currentWeight = null;
    private int weightPosition = RecyclerView.NO_POSITION;
    private ActionMode mode_Action = null;

    private WeightTrackerDatabaseCreator dataDatabase = null; //database creator object will be used to set commands
    private RecyclerView weightsRecyclerView = null;
    private WeightAdapter adapterWeights = null;



    private float weightGoal = 0.f; //declared field for weight goal tracking

    //getter declared
    private List<userWeights> getWeights() {
        return dataDatabase.weightDao().getWeights(dataUsername);
    }

    // on Create method used primarily for instance saving and views
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_tracking);

        if(savedInstanceState != null) {
            dataUsername = savedInstanceState.getString("username");
            weightPosition = savedInstanceState.getInt("selectedWeightPosition");
        }

        Intent intent = getIntent();
        dataUsername = intent.getStringExtra("username");

        dataDatabase = WeightTrackerDatabaseCreator.getInstance(getApplicationContext());

        weightsRecyclerView = findViewById(R.id.listRecyclerView);

        RecyclerView.LayoutManager mLinearLayoutManager = new LinearLayoutManager(getApplicationContext());
        weightsRecyclerView.setLayoutManager(mLinearLayoutManager);

        adapterWeights = new WeightAdapter(getWeights());
        weightsRecyclerView.setAdapter(adapterWeights);

        weightGoal = dataDatabase.accountDao().getGoalWeight(dataUsername);
    }

    // method used for saved instances to keep track of weights and username
    @Override
    public void onSaveInstanceState(@NonNull Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putString("username", dataUsername);
        savedInstanceState.putInt("selectedWeightPosition", weightPosition);
    }

    //will complete action on button click as long as action is determined
    public void onButtonAddWeightClick(View view){
        if (mode_Action != null) {
            mode_Action.finish();
            mode_Action = null;
        }

        //calls fragment manager to show add wieght dialog
        FragmentManager manager = getSupportFragmentManager();
        AddWeightDialogFragment dialog = new AddWeightDialogFragment(); //add weight dialog

        dialog.show(manager, "addWeightDialog"); //show dialog
    }

    //method to add weight to database
    @Override
    public void onWeightAdd(float newWeight) {
        String sendSMSPermission = Manifest.permission.SEND_SMS;
        // create a weight object to store the user weight with the associated username
        userWeights weight = new userWeights(newWeight, dataUsername);

        //call the insert command to insert weight into database table
        dataDatabase.weightDao().insertWeight(weight);

        //call weight adapter
        adapterWeights.addWeight(weight);

        //Here I have a conditional statement for if the weight that is entered is not empty and it is equal to or less
        //than the weight goal, I will call the sms manager and send a sms message with congratulations
        if(weight != null &&
                weight.getWeight() <= weightGoal &&
                checkSelfPermission(sendSMSPermission) == PackageManager.PERMISSION_GRANTED){
            String notificationNumber = getString(R.string.default_phone_number); //this is the phone number that will show
            String smsMessage = String.format(Locale.ENGLISH,"Congratulations! You reached your goal weight at %f Lbs!", weightGoal);
            SmsManager smsManager = SmsManager.getDefault(); // calling the sms manager
            smsManager.sendTextMessage(notificationNumber,null, smsMessage, null, null);
        }
    }

    //This is the method for when the weight is edited
    @Override
    public void onWeightEdit(float newWeight) {
        //Conditional statement to ensure correct function
        if(weightPosition == RecyclerView.NO_POSITION) {
            throw new RuntimeException();
        } else if(currentWeight == null) {
            currentWeight = getWeights().get(weightPosition);
        }

        currentWeight.setWeight(newWeight); //set weight to user input

        dataDatabase.weightDao().updateWeight(currentWeight); //call update command to update weight

        adapterWeights.editWeight(weightPosition, currentWeight); //call edit weight command to edit weight

        currentWeight = null; //default weight value
        weightPosition = RecyclerView.NO_POSITION; //default recycler weight position
    }

    // action call back for recycler list weight selections
    private ActionMode.Callback userActionModeCallback = new ActionMode.Callback() {
        private boolean dialogCreated = false;

        // used if user deselects a weight
        public void itemDeselector(){
            int oldPos = weightPosition;
            currentWeight = null;
            weightPosition = RecyclerView.NO_POSITION;
            adapterWeights.notifyItemChanged(oldPos);
        }

        // shows context menu when weight is selected
        @Override
        public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
            MenuInflater inflater = actionMode.getMenuInflater();
            inflater.inflate(R.menu.context_menu, menu);
            return true;
        }

        //makes sure menu is ready for use
        @Override
        public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
            return false;
        }

        //This is the method I used to determine what happens when itemns in the context menu are pressed
        @Override
        public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
            switch (menuItem.getItemId()) {
                case R.id.deleteWeight: //deletes the selected weight and removes from list
                    dataDatabase.weightDao().deleteWeight(currentWeight);
                    adapterWeights.removeWeight(weightPosition);

                    actionMode.finish();
                    return true;

                case R.id.editWeight: //edits and updates the current weight
                    FragmentManager manager = getSupportFragmentManager();
                    EditWeightDialogFragment dialog = new EditWeightDialogFragment();

                    dialog.show(manager, "editWeightDialog");
                    dialogCreated = true;

                    actionMode.finish();
                    return true;

                default: //default value needed for this type of switch case
                    return false;
            }
        }

        //This is used once an item is deselected but an open dialog exits such as editing a weight
        @Override
        public void onDestroyActionMode(ActionMode actionMode) {
            if(!dialogCreated){
                itemDeselector();
            }//prevents deselection
            mode_Action = null;
        }
    };

    //This class is used for view management
    private class weightViewContainer extends RecyclerView.ViewHolder
                            implements View.OnClickListener {
        TextView mTextViewWeightDate = null;
        TextView mTextViewWeightValue = null;

        userWeights mWeight = null;

        public weightViewContainer(LayoutInflater layoutInflater, ViewGroup parent){
            super(layoutInflater.inflate(R.layout.recycler_view_items,parent, false));

            itemView.setOnClickListener(this);

            mTextViewWeightDate = itemView.findViewById(R.id.textViewWeightDate);
            mTextViewWeightValue = itemView.findViewById(R.id.textViewWeightValue);
        }

        public void bindWeight(userWeights weight, int position) {
            mWeight = weight;

            mTextViewWeightDate.setText(String.format("%tD", mWeight.getDateTime()));
            mTextViewWeightValue.setText(String.format("%f Lbs", mWeight.getWeight()));

            if(weightPosition == position) {
                mTextViewWeightValue.getRootView().setBackgroundColor(getResources().getColor(R.color.teal_200, getTheme()));
            } else {
                mTextViewWeightValue.getRootView().setBackgroundColor(Color.TRANSPARENT);
            }
        }

        @Override
        public void onClick(View view) {
            if (mode_Action != null) {
                mode_Action.finish();
                mode_Action = null;
            }

            currentWeight = mWeight;
            weightPosition = getAdapterPosition();

            adapterWeights.notifyItemChanged(weightPosition);

            mode_Action = WeightTracker.this.startActionMode(userActionModeCallback);
        }
    }

    //This is the weight adapter class for the recycler view which contains the possible actions on list items
    private class WeightAdapter extends RecyclerView.Adapter<weightViewContainer> {
        private List<userWeights> mWeights;

        public WeightAdapter(List<userWeights> weights) {
            mWeights = weights;
        }


        public void removeWeight(int position){ //remove weight from list
            mWeights.remove(position);

            notifyItemRemoved(position);
        }

        public void addWeight(userWeights weight) { //add a weight to the list
            mWeights.add(0, weight);

            notifyItemInserted(0);

            weightsRecyclerView.scrollToPosition(0);
        }

        public void editWeight(int position, userWeights newWeight) { //edit weight in list
            mWeights.set(position, newWeight);

            notifyItemChanged(position);
        }

        @NonNull
        @Override
        public weightViewContainer onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getApplicationContext());
            return new weightViewContainer(layoutInflater, parent); //shows view based on app context
        }

        @Override
        public void onBindViewHolder(@NonNull weightViewContainer holder, int position) {
            holder.bindWeight(mWeights.get(position), position);
        }

        @Override
        public int getItemCount() {
            return mWeights.size();
        }
    }
}
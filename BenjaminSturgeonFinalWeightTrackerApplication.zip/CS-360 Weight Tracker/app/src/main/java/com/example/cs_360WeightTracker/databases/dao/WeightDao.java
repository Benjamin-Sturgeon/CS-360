package com.example.cs_360WeightTracker.databases.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.cs_360WeightTracker.databases.commands.userWeights;

import java.util.List;

@Dao
public interface WeightDao {
    @Query("SELECT * from weights WHERE username = :username ORDER BY datetime DESC")
    public List<userWeights> getWeights(String username);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insertWeight(userWeights weight);

    @Update
    public void updateWeight(userWeights weight);

    @Delete
    void deleteWeight(userWeights weight);
}

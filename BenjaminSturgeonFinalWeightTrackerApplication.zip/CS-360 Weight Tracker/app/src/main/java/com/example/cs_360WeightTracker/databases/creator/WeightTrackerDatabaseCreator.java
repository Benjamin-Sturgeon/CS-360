package com.example.cs_360WeightTracker.databases.creator;
//Benjamin Sturgeon

//necessary imports
import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.cs_360WeightTracker.databases.commands.userAccounts;
import com.example.cs_360WeightTracker.databases.commands.userWeights;
import com.example.cs_360WeightTracker.databases.dao.AccountDao;
import com.example.cs_360WeightTracker.databases.dao.WeightDao;

@Database(entities = {userAccounts.class, userWeights.class}, version = 1)
public abstract class WeightTrackerDatabaseCreator extends RoomDatabase {
    private final static String FILE_NAME = "weight_tracker_database.db";

    private static WeightTrackerDatabaseCreator userWeightDatabase;

    public static WeightTrackerDatabaseCreator getInstance(Context context) {
        if (userWeightDatabase == null) {
            userWeightDatabase = Room.databaseBuilder(context, WeightTrackerDatabaseCreator.class,
                    FILE_NAME).allowMainThreadQueries().build();
        }
        return userWeightDatabase;
    }

    public abstract AccountDao accountDao();

    public abstract WeightDao weightDao();
}

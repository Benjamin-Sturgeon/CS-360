package com.example.cs_360WeightTracker;
//Benjamin Sturgeon CS-360

//necessary imports
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;


import com.example.cs_360WeightTracker.ChangeActivites.SetGoalWeightDialogFragment;
import com.example.cs_360WeightTracker.SMS.SMSPermissionDialogMessagePrompt;
import com.example.cs_360WeightTracker.databases.creator.WeightTrackerDatabaseCreator;
import com.example.cs_360WeightTracker.databases.commands.userAccounts;
import com.example.cs_360WeightTracker.databases.security.HashSaltSecurity;

public class MainActivity extends AppCompatActivity implements TextWatcher,
                                SetGoalWeightDialogFragment.OnSetGoalWeightListener,
                                SMSPermissionDialogMessagePrompt.OnSendSMSPermissionRationaleDialogResultListener {
    private static final int SEND_SMS_REQUEST_CODE = 0;

    //necessary fields
    private String userSession = null;
    private EditText userNameTextEditor;
    private EditText passwordTextEditor;
    private TextView textViewErrorPrompt;
    private WeightTrackerDatabaseCreator userDatabase; //use database creator to create commands object

    //Here I create a method to validate the new username and password when created
    private boolean newUsernameAndPasswordValidator(String user, String pass){
        if(user.trim().length() <= 0 || pass.trim().length() <= 0) //makes sure fields aren't empty
            return false;

        return userDatabase.accountDao().getPassword(user) == null; // returns null value
    }

    //Here I create a validtion for the username and password based on the database values
    private boolean userNameAndPasswordValidator(String user, String pass){
        String hashForDatabase = userDatabase.accountDao().getPassword(user);
        byte [] saltForDatabase = userDatabase.accountDao().getSalt(user); //necessary conversions to obtain useable values from database

        //return true or false based on equals comparison for values will return false if either username or password is incorrect
        return (hashForDatabase != null) && (saltForDatabase != null) && hashForDatabase.equals(HashSaltSecurity.getHash(pass, saltForDatabase));
    }

    //Method for checking SMS permission
    private boolean hasSendSMSPermissions() {
        String sendSMSPermission = Manifest.permission.SEND_SMS;
        if(checkSelfPermission(sendSMSPermission) != PackageManager.PERMISSION_GRANTED) {
            if (shouldShowRequestPermissionRationale(sendSMSPermission)) {
                FragmentManager manager = getSupportFragmentManager();
                SMSPermissionDialogMessagePrompt dialog = new SMSPermissionDialogMessagePrompt(); //show sms permission prompt reason from fragment manager

                dialog.show(manager, "SMSPermissionDialogMessagePrompt");// test sms
            } else {
                requestPermissions(new String[] { sendSMSPermission }, SEND_SMS_REQUEST_CODE);
            }
            return false;
        }
        return true;
    }

    //Method to check permission result
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        loginMethod();
    }

        //This is the base login method to call the intent for the main weight tracker program after login
    private void loginMethod(){
        Intent intent = new Intent(this, WeightTracker.class);
        intent.putExtra("username", userSession); //open the intent with the associated user session
        startActivity(intent);
    }

    //onCreate used for saving instances and views
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(savedInstanceState != null) {
            userSession = savedInstanceState.getString("sessionToken");
        }

        if(userSession != null){
            loginMethod();
        }

        userNameTextEditor = findViewById(R.id.editUserNameText);
        textViewErrorPrompt = findViewById(R.id.loginActivityErrorTextView);
        passwordTextEditor = findViewById(R.id.editPasswordText);

        userNameTextEditor.addTextChangedListener(this);
        passwordTextEditor.addTextChangedListener(this);

        userDatabase = WeightTrackerDatabaseCreator.getInstance(getApplicationContext());
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putString("sessionToken", userSession);
    }

    //Primary method used to create new accounts and store them in the account database
    public void onButtonNewAccountClick(View view){

        //username and passsword fields for processing
        String newUsername = userNameTextEditor.getText().toString();
        String newPassword = passwordTextEditor.getText().toString();


        if(newUsernameAndPasswordValidator(newUsername, newPassword)) {
            byte [] salt = HashSaltSecurity.getSalt();
            String hash = HashSaltSecurity.getHash(newPassword, salt);
            userDatabase.accountDao().insertAccount(new userAccounts(newUsername, hash, salt));

            userSession = newUsername;

            FragmentManager manager = getSupportFragmentManager();
            SetGoalWeightDialogFragment dialog = new SetGoalWeightDialogFragment();
            dialog.show(manager, "setGoalWeightDialog"); //after new account creation user sets goal weight.
        } else {
            textViewErrorPrompt.setText(R.string.error_text_new_account);
            textViewErrorPrompt.setVisibility(View.VISIBLE);
        }
    }

    public void onButtonLogInClick(View view){
        String username = userNameTextEditor.getText().toString();
        String password = passwordTextEditor.getText().toString();

        if(userNameAndPasswordValidator(username, password)){
            userSession = username;
            loginMethod();
        } else {
            textViewErrorPrompt.setText(R.string.error_text_log_in);
            textViewErrorPrompt.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        if(textViewErrorPrompt.getVisibility() == View.VISIBLE){
            textViewErrorPrompt.setText("");
            textViewErrorPrompt.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void afterTextChanged(Editable editable) { }

    @Override
    public void onSetGoalWeight(float weight) {
        if(userSession == null)
            throw new RuntimeException();

        userDatabase.accountDao().setGoalWeight(weight, userSession);

        if(hasSendSMSPermissions())
            loginMethod();
    }

    //method to check sms permission response after warning prompt
    @Override
    public void onSMSPermissionDialogMessagePrompt(boolean result) {
        String sendSMSPermission = Manifest.permission.SEND_SMS;

        if(result) {
            requestPermissions(new String[] { sendSMSPermission }, SEND_SMS_REQUEST_CODE);
        } else {
            loginMethod();
        }
    }
}